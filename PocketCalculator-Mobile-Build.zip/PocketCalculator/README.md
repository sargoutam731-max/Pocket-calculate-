# Pocket Calculator

A native Android calculator built with Kotlin and Jetpack Compose.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android version: Android 6.0 (API 23). The calculator works offline.

This archive contains the Android Studio project source; it is not a compiled APK.
