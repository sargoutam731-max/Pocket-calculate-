package com.brainblaze.pocketcalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.MathContext

private val Bg = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2A)
private val Key = Color(0xFF252838)
private val Accent = Color(0xFF9B8CFF)
private val Muted = Color(0xFF9DA2B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CalculatorApp() }
    }
}

@Composable
fun CalculatorApp() {
    var display by remember { mutableStateOf("0") }
    var stored by remember { mutableStateOf<BigDecimal?>(null) }
    var operation by remember { mutableStateOf<String?>(null) }
    var fresh by remember { mutableStateOf(false) }
    var expression by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<String>()) }

    fun tidy(v: BigDecimal): String = v.stripTrailingZeros().toPlainString().let { if (it == "-0") "0" else it }
    fun current() = display.toBigDecimalOrNull() ?: BigDecimal.ZERO
    fun input(s: String) {
        if (fresh) { display = if (s == ".") "0." else s; fresh = false; return }
        display = when {
            s == "." && display.contains(".") -> display
            display == "0" && s != "." -> s
            display == "-0" && s != "." -> "-$s"
            display.length >= 15 -> display
            else -> display + s
        }
    }
    fun choose(op: String) {
        stored = current(); operation = op; expression = "$display $op"; fresh = true
    }
    fun equalsNow() {
        val a = stored ?: return
        val b = current()
        val result = try {
            when (operation) {
                "+" -> a.add(b)
                "−" -> a.subtract(b)
                "×" -> a.multiply(b)
                "÷" -> if (b.compareTo(BigDecimal.ZERO) == 0) null else a.divide(b, MathContext.DECIMAL64)
                else -> b
            }
        } catch (_: Exception) { null }
        if (result == null) { display = "Error"; expression = "Cannot divide by zero" }
        else {
            val old = "$expression $display = ${tidy(result)}"
            history = (listOf(old) + history).take(30)
            expression = "$expression $display ="
            display = tidy(result)
        }
        stored = null; operation = null; fresh = true
    }
    fun clear() { display = "0"; stored = null; operation = null; expression = ""; fresh = false }
    fun percent() { display = tidy(current().divide(BigDecimal(100), MathContext.DECIMAL64)); fresh = true }
    fun sign() { display = if (display.startsWith("-")) display.drop(1) else if (display == "0") "0" else "-$display" }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Accent)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp, vertical = 18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("POCKET", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("Calculator", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                Text("HISTORY  ↗", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { /* history is shown below */ }.padding(8.dp))
            }
            Spacer(Modifier.height(24.dp))
            Column(Modifier.fillMaxWidth().weight(1f).background(Panel, RoundedCornerShape(28.dp)).padding(22.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.Bottom) {
                Text(expression, color = Muted, fontSize = 17.sp, maxLines = 1)
                Spacer(Modifier.height(10.dp))
                Text(display, color = Color.White, fontSize = if (display.length > 10) 38.sp else 54.sp, fontWeight = FontWeight.Light, maxLines = 1, textAlign = TextAlign.End)
            }
            Spacer(Modifier.height(18.dp))
            val rows = listOf(
                listOf("AC", "±", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "−"),
                listOf("1", "2", "3", "+"),
                listOf("⌫", "0", ".", "=")
            )
            rows.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { label ->
                        val special = label in listOf("÷", "×", "−", "+", "=")
                        val utility = label in listOf("AC", "±", "%", "⌫")
                        Box(Modifier.weight(if (label == "0") 1.15f else 1f).height(68.dp)
                            .background(if (special) Accent else if (utility) Color(0xFF34364A) else Key, RoundedCornerShape(22.dp))
                            .clickable {
                                when (label) {
                                    "AC" -> clear()
                                    "±" -> sign()
                                    "%" -> percent()
                                    "⌫" -> { if (!fresh && display.isNotEmpty()) display = display.dropLast(1).ifEmpty { "0" } }
                                    "+", "−", "×", "÷" -> choose(label)
                                    "=" -> equalsNow()
                                    else -> input(label)
                                }
                            }, contentAlignment = Alignment.Center) {
                            Text(label, color = if (special) Color(0xFF171528) else Color.White, fontSize = if (label.length > 1) 19.sp else 25.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            if (history.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Recent calculations", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("CLEAR", color = Accent, fontSize = 11.sp, modifier = Modifier.clickable { history = emptyList() }.padding(6.dp))
                }
                history.take(2).forEach { Text(it, color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), textAlign = TextAlign.End, maxLines = 1) }
            } else {
                Text("Simple • Fast • Offline", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), textAlign = TextAlign.Center)
            }
        }
    }
}
